/*
    Copyright 2021 NXP  
    NXP Confidential. This software is owned or controlled by NXP and may only be 
    used strictly in accordance with the applicable license terms. By expressly 
    accepting such terms or by downloading, installing, activating and/or otherwise
    using the software, you are agreeing that you have read, and that you agree to
    comply with and are bound by, such license terms.  If you do not agree to be 
    bound by the applicable license terms, then you may not retain, install, 
    activate or otherwise use the software.
 */


/******************************************************************************
 *   Project              : STRX_RFE_SW
 *   Platform             : STRX_ONE_CHIP
 *****************************************************************************/

#ifndef RFE_CONFIG_H
#define RFE_CONFIG_H


/******************************************************************************
 *                              INCLUDES
 *****************************************************************************/

#include "rfeApi.h"


/******************************************************************************
 *                              TYPES
 *****************************************************************************/

 /**
 * This variable contains all the rfe configuration parameter values
 */
extern rfeApi_params_t rfeConfig;

 /**
 * This variable contains the dynamic tables
 */
extern uint32_t rfeConfig_dynamicTables[];


/******************************************************************************
 *                              FUNCTIONS
 *****************************************************************************/



#endif // !RFE_CONFIG_H
