/*
    Copyright 2021 NXP  
    NXP Confidential. This software is owned or controlled by NXP and may only be 
    used strictly in accordance with the applicable license terms. By expressly 
    accepting such terms or by downloading, installing, activating and/or otherwise
    using the software, you are agreeing that you have read, and that you agree to
    comply with and are bound by, such license terms.  If you do not agree to be 
    bound by the applicable license terms, then you may not retain, install, 
    activate or otherwise use the software.
 */


 /******************************************************************************
  *   Project              : SAF85xx_RFE_FW
  *   Platform             : SAF85xx
  *****************************************************************************/

#ifndef RFE_DRV_DYN_TBL_H
#define RFE_DRV_DYN_TBL_H

/******************************************************************************
 *                              INCLUDES
 *****************************************************************************/

#include "rfeApi_params.h"

#include <stdint.h>
#include <stdbool.h>


/******************************************************************************
 *                              TYPES
 *****************************************************************************/

/**
 * Pointer to an uint8_t based sequence contained in the dynamic table.
 */
typedef struct
{
    /**
	 * Pointer to the first element in the uint8_t based sequence.
     * This will be set 0 (NULL) if the sequence does not exist in the dynamic table.
     */
    uint8_t*    pointer;
    /**
	 * Number of items in the sequence.
     * This will be set to 0 if the sequence does not exist in the dynamic table.
     */
    uint16_t    sequenceLength;
} rfeDrvDynTbl_pUint8_t;

/**
 * Pointer to an uint16_t based sequence contained in the dynamic table.
 */
typedef struct
{
    /**
	 * Pointer to the first element in the uint8_t based sequence.
     * This will be set 0 (NULL) if the sequence does not exist in the dynamic table.
     */
    uint16_t*   pointer;
	/**
	 * Number of items in the sequence.
     * This will be set to 0 if the sequence does not exist in the dynamic table.
     */
    uint16_t    sequenceLength;
} rfeDrvDynTbl_pUint16_t;

/**
 * Pointer to an uint32_t based sequence contained in the dynamic table.
 */
typedef struct
{
    /**
	 * Pointer to the first element in the uint8_t based sequence.
     * This will be set 0 (NULL) if the sequence does not exist in the dynamic table.
     */
    uint32_t*   pointer;
    /**
	 * Number of items in the sequence.
     * This will be set to 0 if the sequence does not exist in the dynamic table.
     */
    uint16_t    sequenceLength;
} rfeDrvDynTbl_pUint32_t;

/**
 * Range information for a part of the dynamic table.
 */
typedef struct
{
    /**
     * The start offset in bytes from the beginning of the dynamic table.
     * This will be set 0 if the requested range does not exist in the dynamic table.
     */
    uint16_t    offset;
    /**
     * The number of bytes in the range.
     * This will be set 0 if the requested range does not exist in the dynamic table.
     */
    uint16_t    size;
} rfeDrvDynTbl_range_t;


/******************************************************************************
 *                              FUNCTIONS
 *****************************************************************************/

/**
 * \brief Gets the range of the entire dynamic table.
 *
 * \details Gets the range of the entire dynamic table.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable Pointer to the dynamic table.
 *
 * \return The range of the entire dynamic table.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
rfeDrvDynTbl_range_t rfeDrvDynTbl_getFullMemoryRange
(
    const uint32_t* const           pDynamicTable
);

/**
 * \brief Gets the table count.
 *
 * \details Gets the number of the dynamic tables.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable Pointer to the dynamic table.
 *
 * \return The table count.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
uint8_t rfeDrvDynTbl_getTableCount
(
    const uint32_t* const           pDynamicTable
);

/**
 * \brief Gets the range for the specified table index.
 *
 * \details Gets the range for the specified table index.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable     Pointer to the dynamic table.
 * \param [in]  dynamicTableIndex Table index.
 *
 * \return The range of the specified table index.
 *         This will be set to 0 if the table index is invalid.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
rfeDrvDynTbl_range_t rfeDrvDynTbl_getTableMemoryRange
(
    const uint32_t* const           pDynamicTable,
    uint8_t                         dynamicTableIndex
);

/**
 * \brief Gets the sequence length for the specified table index.
 *
 * \details Gets the sequence length for the specified table index.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable     Pointer to the dynamic table.
 * \param [in]  dynamicTableIndex Table index.
 *
 * \return The sequence length for the specified table index.
 *         This will be set to 0 if the table index is invalid.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
uint16_t rfeDrvDynTbl_getTableSequenceLength
(
    const uint32_t* const           pDynamicTable,
    uint8_t                         dynamicTableIndex
);

/**
 * \brief Gets a pointer to the start of the chirp profile sequence for the specified table index.
 *
 * \details Gets a pointer to the start of the chirp profile sequence for the specified table index.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable     Pointer to the dynamic table.
 * \param [in]  dynamicTableIndex Table index.
 *
 * \return The pointer to the start of the chirp profile sequence for the specified table index.
 *         This pointer and sequenceLength returned will be set to zero if the table index is invalid.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
rfeDrvDynTbl_pUint8_t rfeDrvDynTbl_getChirpProfileSequence
(
    const uint32_t* const           pDynamicTable,
    uint8_t                         dynamicTableIndex
);

/**
 * \brief Gets a pointer to the start of the tx phase rotation sequence for the specified table index.
 *
 * \details Gets a pointer to the start of the tx phase rotation sequence for the specified table index.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable     Pointer to the dynamic table.
 * \param [in]  dynamicTableIndex Table index.
 * \param [in]  txIndex           TX index.
 *
 * \return The pointer to the start of the tx phase rotation sequence for the specified table index.
 *         This pointer and sequenceLength returned will be set to zero if the table index is invalid.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
rfeDrvDynTbl_pUint8_t rfeDrvDynTbl_getTxPhaseRotationSequence
(
    const uint32_t* const           pDynamicTable,
    uint8_t                         dynamicTableIndex,
    rfeApi_txIndex_t                txIndex
);

/**
 * \brief Gets a pointer to the start of the tx transmission enable sequence for the specified table index.
 *
 * \details Gets a pointer to the start of the tx transmission enable sequence for the specified table index.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable     Pointer to the dynamic table.
 * \param [in]  dynamicTableIndex Table index.
 *
 * \return The pointer to the start of the tx transmission enable sequence for the specified table index.
 *         This pointer and sequenceLength returned will be set to zero if the table index is invalid.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
rfeDrvDynTbl_pUint8_t rfeDrvDynTbl_getTxTransmissionEnableSequence
(
    const uint32_t* const           pDynamicTable,
    uint8_t                         dynamicTableIndex
);

/**
 * \brief Gets a pointer to the start of the tx enable sequence for the specified table index.
 *
 * \details Gets a pointer to the start of the tx enable sequence for the specified table index.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable     Pointer to the dynamic table.
 * \param [in]  dynamicTableIndex Table index.
 *
 * \return The pointer to the start of the tx enable sequence for the specified table index.
 *         This pointer and sequenceLength returned will be set to zero if the table index is invalid.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
rfeDrvDynTbl_pUint8_t rfeDrvDynTbl_getTxEnableSequence
(
    const uint32_t* const           pDynamicTable,
    uint8_t                         dynamicTableIndex
);

/**
 * \brief Gets a pointer to the start of the dwell time ticks sequence for the specified table index.
 *
 * \details Gets a pointer to the start of the dwell time ticks sequence for the specified table index.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable     Pointer to the dynamic table.
 * \param [in]  dynamicTableIndex Table index.
 *
 * \return The pointer to the start of the dwell time ticks sequence for the specified table index.
 *         This pointer and sequenceLength returned will be set to zero if the table index is invalid.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
rfeDrvDynTbl_pUint16_t rfeDrvDynTbl_getDwellTimeTicksSequence
(
    const uint32_t* const           pDynamicTable,
    uint8_t                         dynamicTableIndex
);

/**
 * \brief Gets a pointer to the start of the settle time ticks sequence for the specified table index.
 *
 * \details Gets a pointer to the start of the sette time ticks sequence for the specified table index.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable     Pointer to the dynamic table.
 * \param [in]  dynamicTableIndex Table index.
 *
 * \return The pointer to the start of the settle time ticks sequence for the specified table index.
 *         This pointer and sequenceLength returned will be set to zero if the table index is invalid.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
rfeDrvDynTbl_pUint16_t rfeDrvDynTbl_getSettleTimeTicksSequence
(
    const uint32_t* const           pDynamicTable,
    uint8_t                         dynamicTableIndex
);

/**
 * \brief Gets a pointer to the start of the chirp interval time ticks sequence for the specified table index.
 *
 * \details Gets a pointer to the start of the chirp interval time ticks sequence for the specified table index.
 *
 * \pre The dynamic table must be properly initialized.
 *
 * \param [in]  pDynamicTable     Pointer to the dynamic table.
 * \param [in]  dynamicTableIndex Table index.
 *
 * \return The pointer to the start of the chirp interval time ticks sequence for the specified table index.
 *         This pointer and sequenceLength returned will be set to zero if the table index is invalid.
 *
 * \post NIL
 *
 * \ingroup NIL
 */
rfeDrvDynTbl_pUint32_t rfeDrvDynTbl_getChirpIntervalTimeTicksSequence
(
    const uint32_t* const           pDynamicTable,
    uint8_t                         dynamicTableIndex
);

#endif // !RFE_DRV_DYN_TBL_H
