var searchData=
[
  ['isconfigured',['isConfigured',['../structrfe_api__state__t.html#a2e813ffcb6defeae2490eb1cf6c0418a',1,'rfeApi_state_t']]],
  ['isdynamicupdatesenabled',['isDynamicUpdatesEnabled',['../structrfe_api__chirp_sequence_params__t.html#abea31730f78d4efccec59414d524671b',1,'rfeApi_chirpSequenceParams_t']]],
  ['isradarcycleactive',['isRadarCycleActive',['../structrfe_api__state__t.html#a22cba939ccf54f662bf7231e2b3247e5',1,'rfeApi_state_t']]]
];
