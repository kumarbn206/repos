var searchData=
[
  ['hwtype',['hwType',['../structrfe_api__info__t.html#a5cb02c01611390eea8a37a11d1514f4a',1,'rfeApi_info_t']]],
  ['hwvariant',['hwVariant',['../structrfe_api__info__t.html#ac5d8cd274e32ea720977b9f8d7bd9d5e',1,'rfeApi_info_t']]],
  ['hwversion',['hwVersion',['../structrfe_api__info__t.html#a99c1789f51d3234a958f8f9ed068ed78',1,'rfeApi_info_t']]]
];
