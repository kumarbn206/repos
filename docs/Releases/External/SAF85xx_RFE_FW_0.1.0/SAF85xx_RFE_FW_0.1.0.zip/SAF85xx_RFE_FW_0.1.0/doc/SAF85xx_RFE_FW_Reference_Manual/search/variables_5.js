var searchData=
[
  ['functionalstate',['functionalState',['../structrfe_api__state__t.html#ab9be293c9b4d6da2f548cc7b2e4957a4',1,'rfeApi_state_t']]],
  ['fwvariant',['fwVariant',['../structrfe_api__info__t.html#ad705d5ca5fad6c6fa6c6f62a18e2af40',1,'rfeApi_info_t']]],
  ['fwversion',['fwVersion',['../structrfe_api__info__t.html#a5697aec0eb1895dc5325d8c22d91a056',1,'rfeApi_info_t']]]
];
