/*
    Copyright 2021 NXP  
    NXP Confidential. This software is owned or controlled by NXP and may only be 
    used strictly in accordance with the applicable license terms. By expressly 
    accepting such terms or by downloading, installing, activating and/or otherwise
    using the software, you are agreeing that you have read, and that you agree to
    comply with and are bound by, such license terms.  If you do not agree to be 
    bound by the applicable license terms, then you may not retain, install, 
    activate or otherwise use the software.
 */


/******************************************************************************
 *   Project              : SAF85xx_RFE_FW
 *   Platform             : SAF85xx
 *****************************************************************************/

#ifndef RFE_API_H
#define RFE_API_H


/******************************************************************************
 *                              INCLUDES
 *****************************************************************************/

#include "rfeApi_error.h"
#include "rfeApi_params.h"
#include "rfeApi_chirp.h"


/******************************************************************************
 *                              FILE VERSION INFORMATION
 *****************************************************************************/

#define RFE_API_MAJOR_VERSION                               ( 0ul )
#define RFE_API_MINOR_VERSION                               ( 1ul )
#define RFE_API_PATCH_VERSION                               ( 0ul )


/******************************************************************************
 *                              TYPES
 *****************************************************************************/

/**
 * This enumerated type defines rfe functional states.
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_functionalState_powerUp_e,
    rfeApi_functionalState_waitForInit_e,
    rfeApi_functionalState_init_e,
    rfeApi_functionalState_safetyMonitoringCheck_e,
    rfeApi_functionalState_integrityCheck_e,    
    rfeApi_functionalState_initChirpSequence_e,  
    rfeApi_functionalState_calibration_e,
    rfeApi_functionalState_chirpSequence_e,
    rfeApi_functionalState_bist_e,
    rfeApi_functionalState_idle_e,
    rfeApi_functionalState_commandBusy_e,
    rfeApi_functionalState_continuousWaveTransmission_e
} rfeApi_functionalState_t;


/**
 * This enumerated type defines rfe safety states.
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_safetyState_notMonitoring_e,
    rfeApi_safetyState_ok_e,
    rfeApi_safetyState_errorRecovery_e,
    rfeApi_safetyState_errorPermanent_e
} rfeApi_safetyState_t;


/**
 * This structure contains the rfe static parameters.
 */
typedef struct RFE_API_ATTRIBUTE_PACKED
{
    /** Selects the powerMode of the rfe */
    rfeApi_powerMode_t powerMode;
    /** 
     * Enables dynamic power mode for selected rfe components. While dynamic
     * power mode is enabled, the component is enabled during a chirp and
     * disabled in-between chirps. When disabled, the component is enabled
     * during the complete chirp sequence.
     */
    rfeApi_dynamicPowerEnable_t dynamicPowerEnable;
    /** 
     * Enables the IO signal that indicates when a radar cycles starts
     * When enabled, this IO will output an high pulse at the start of each radar cycle 
     */
    bool radarCycleStartIoSignalEnable;
    /** 
     * Enables the IO signal that indicates when a chirp (sequence) is active
     * When enabled, this IO will be high during each chirp (sequence)
     * This signal can be configured by #chirpActiveIoSignalConfig.
     */
    bool chirpActiveIoSignalEnable;
    /** 
     * Configures the IO signal that indicates when a chirp (sequence) is active. 
     */
    rfeApi_chirpActiveIoSignal_t chirpActiveIoSignalConfig;
    /** Configures the CLK_IN / CLK_OUT IO parameters */
    rfeApi_clkInOut_t clkInOutParams;
    /** Enables/disables programmable decimation chain DC notch filter */
    bool pdcDcNotchFilterEnable;
    /** Configures the programmable decimation chain notch filter coefficients */
    uint16_t pdcDcNotchFilterCoefficient;
    /** Selects the programmable decimation chain bandwidth */
    rfeApi_pdcBandwidth_t pdcBandwidthSelect;
    /** Selects the programmable decimation chain bit width */
    rfeApi_pdcBitwidth_t pdcBitwidth;
    /** Selects the destination of the sample data output */
    rfeApi_dataOutDest_t dataOutDest;
    /** Configures the sample data output */
    rfeApi_dataOutConfig_t dataOutConfig;
} rfeApi_staticParams_t;


/**
 * This structure contains the rfe monitor and safety parameters.
 */
typedef struct RFE_API_ATTRIBUTE_PACKED
{
    /** Enable/disable resetting of the receiver saturation counts every chirp sequence */
    bool rxSatCountResetEveryChirpSequence;
    /** The power threshold a sample must exceed in the first receiver stage to be counted as satured */
    rfeApi_rxSaturationThreshold_t rxSatThresholdStage1[RFE_API_RX_COUNT];
    /** The power threshold a sample must exceed in the second receiver stage to be counted as satured */
    rfeApi_rxSaturationThreshold_t rxSatThresholdStage2[RFE_API_RX_COUNT];
    /** The amount of staturations in the first receiver stage that raises an error  */
    uint32_t rxSatCountMaxStage1[RFE_API_RX_COUNT];
    /** The amount of staturations in the second receiver stage that raises an error */
    uint32_t rxSatCountMaxStage2[RFE_API_RX_COUNT];
    /** Enable/disable resetting of the programmable decimation chain clipping counts every chirp sequence */
    bool pdcClippingCountResetEveryChirpSequence;
    /** The temperature threshold each temperature sensor must exceed to raise an high temperature warning */
    rfeApi_temperature_t tempThresholdHighWarning[RFE_API_TEMPERATURE_SENSOR_COUNT];
    /** The temperature threshold each temperature sensor must exceed to raise an over temperature error */
    rfeApi_temperature_t tempThresholdOverError[RFE_API_TEMPERATURE_SENSOR_COUNT];
    /** The temperature threshold each temperature sensor must drop below to raise an under temperature error */
    rfeApi_temperature_t tempThresholdUnderError[RFE_API_TEMPERATURE_SENSOR_COUNT];

    /** FCCU parameters are to be defined */

    /** Safety Manager parameters are to be defined*/
    
} rfeApi_monitorAndSafetyParams_t;


/**
 * This macro defines the maxmimum supported chirp sequences per radar cycle.
 */
#define RFE_API_CHIRP_SEQUENCES_PER_RADAR_CYCLE_MAX         ( 4 )


/**
 * This structure contains the rfe radar cycle parameters.
 */
typedef struct RFE_API_ATTRIBUTE_PACKED
{
    /** Radar cycle duration in [us] */
    uint32_t radarCycleDuration;
    /** Number of chirp sequences comprising a radar cycle */
    uint16_t chirpSequenceCount;
    /** The configuration index for each chirp sequence of the radar cycle */
    rfeApi_chirpSequenceConfigIndex_t chirpSequences[RFE_API_CHIRP_SEQUENCES_PER_RADAR_CYCLE_MAX];
    /** The chirp sequence time offset in [us] with respect to the start time of the radar cycle */
    uint32_t chirpSequenceStartTimeOffset[RFE_API_CHIRP_SEQUENCES_PER_RADAR_CYCLE_MAX];
    /** The execution interval to calibrate the rfe */
    rfeApi_calibBistInterval_t calibrationInterval;
    /** The execution interval for rfe built-in-self-tests */
    rfeApi_calibBistInterval_t bistInterval;
} rfeApi_radarCycleParams_t;


/**
 * This structure is a collection of all the rfe parameters.
 */
typedef struct RFE_API_ATTRIBUTE_PACKED
{
    /** Sub-structure that contains the static parameters */
    rfeApi_staticParams_t staticConfig;
    /** Sub-structure that contains the monitor and safety parameters */
    rfeApi_monitorAndSafetyParams_t monitorAndSafetyConfig;
    /** Sub-structure that contains radar cycle parameters */
    rfeApi_radarCycleParams_t radarCycleConfig;
    /** An array of sub-structures that contain the chirp sequence parameters for each configuration index #rfeApi_chirpSequenceConfigIndex_t */
    rfeApi_chirpSequenceParams_t chirpSequenceConfigs[RFE_API_CHIRP_SEQUENCE_CONFIGS_MAX];
    /** An array of sub-structures that contain the chirp profile parameters for each profile index #rfeApi_chirpProfileIndex_t */
    rfeApi_chirpProfileParams_t chirpProfiles[RFE_API_CHIRP_PROFILES_MAX];
    /** Address of the dynamic tables in system memory */
    rfeApi_sysMemAddress_t dynamicTablesAddress;
    /** The number of chirp sequence configuration in use. Must be lower or equal than #RFE_API_CHIRP_SEQUENCE_CONFIGS_MAX */
    uint8_t chirpSequenceConfigCount;
    /** The number of chirp profiles in use. Must be lower or equal than #RFE_API_CHIRP_PROFILES_MAX */
    uint8_t chirpProfileCount;
} rfeApi_params_t;

/**
 * This structure contains the rfe state information.
 */
typedef struct RFE_API_ATTRIBUTE_PACKED
{
    /** Indicates the rfe functional state */
    rfeApi_functionalState_t functionalState;
    /** Indicates wether a radar cycle is active */
    bool isRadarCycleActive;
    /** Indicates wether the rfe is configured */
    bool isConfigured;
    /** Indicates the rfe safety state */
    rfeApi_safetyState_t safetyState;
    /** Number of radar cycles that have been completed since rfeApi_radarCycleStart */
    uint32_t radarCycleCount;
    /** Number of chirp sequences that have been completed within the radar cycle */
    uint8_t chirpSequenceCount;
    /** Indicates what chirp sequence configuration is active / initialized */
    rfeApi_chirpSequenceConfigIndex_t activeChirpSequenceConfig;
} rfeApi_state_t;


/**
 * This structure contains information about the rfe:
 * - Hardware and firmware variants
 * - Hardware and firmware versions
 */
typedef struct RFE_API_ATTRIBUTE_PACKED
{
    /** Contains the IC type, type numbering is TBD */
    uint32_t hwType;
    /** Contains the IC variant, variant numbering is TBD */
    uint32_t hwVariant;
    /** Contains the IC version, version numbering is TBD */
    uint32_t hwVersion;
    /** Contains the firmware variant, variant numbering is TBD */
    uint32_t fwVariant;
    /** Contains the firmware version, version numbering is TBD  */
    uint32_t fwVersion;
} rfeApi_info_t;

/******************************************************************************
 *                              FUNCTIONS
 *****************************************************************************/
 
/**
 * \brief This function initializes the rfe and the interface towards it.
 * 
 * \details This function first initalizes the interface towards the rfe 
 * and then the rfe itself. It shall be the first rfeApi function to call. 
 * This function returns whether rfe has accepted or rejected the API call.
 * 
 * \pre Rfe must be powered up and uninitialized.
 * 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post #rfeApi_state_t.functionalState becomes #rfeApi_functionalState_init_e
 * and initialization is executed after function return.
 * When initilization is ready, #rfeApi_state_t.functionalState becomes #rfeApi_functionalState_idle_e
 * 
 * \ingroup NIL
 */
void rfeApi_init(
    RFE_API_ERROR_FUNCTION_PARAMETER
);


/**
 * \brief This function fully configures the rfe.
 * 
 * \details This function first verifies the provided rfe configuration, 
 * then configures the rfe and execute initial calibration. This function returns
 * whether rfe has accepted or rejected the API call and configuration.
 * 
 * \pre 
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * - #rfeApi_state_t.isRadarCycleActive must be false.
 * 
 * \param [in]      pConfig - Pointer to configuration structure in system memory
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post #rfeApi_state_t.functionalState becomes #rfeApi_functionalState_commandBusy_e and 
 * configuration/initial calibration is executed after function return. 
 * When done #rfeApi_state_t.functionalState becomes #rfeApi_functionalState_idle_e
 * and #rfeApi_state_t.isConfigured becomes true.
 * 
 * \ingroup NIL
 */
void rfeApi_config(
    const rfeApi_params_t *pConfig,
    RFE_API_ERROR_FUNCTION_PARAMETER
);


/**
 * \brief This function starts the configured radar cycle.
 * 
 * \details This function starts the configured radar cycle at the startTime
 * or as soon as possible. This function returns whether rfe has accepted or 
 * rejected the API call.
 * 
 * \pre 
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e,
 * - #rfeApi_state_t.isConfigured must be true
 * - #rfeApi_state_t.isRadarCycleActive must be false.
 * 
 * \param [in]      radarCycleCount - Number of radar cycles to start.
 *                  A value of 0 indicates an infinite number of radar cycles,
 *                  i.e. until stopped by rfeApi_radarCycleStop().
 *  \param [in]     isScheduled - If true, radar cycle starts at \p startTime.
 *                  If false radar cycle starts as soon as possible.
 * \param [in]      startTime - The absolute start time in [us] of the chirp 
 *                  sequence according to the rfe time.
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post When call is accepted #rfeApi_state_t.isRadarCycleActive becomes true
 * and the radar cycle is started at the provided start time. When all radar 
 * cycles are done #rfeApi_state_t.isRadarCycleActive returns to false.
 * 
 * \ingroup NIL
 */
void rfeApi_radarCycleStart(
    uint16_t radarCycleCount,
    bool isScheduled,
    uint32_t startTime,
    RFE_API_ERROR_FUNCTION_PARAMETER
);


/**
 * \brief This function stops the active radar cycle.
 * 
 * \details This function stops the active radar cycle. It returns whether 
 * rfe has accepted or rejected the API call. It can be called to stop rfe 
 * operation, e.g. when a reconfiguration is needed that comprised of more
 * than a few parameter changes.
 * 
 * \pre 
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * - #rfeApi_state_t.isRadarCycleActive must be true
 *
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post When call is accepted, #rfeApi_state_t.isRadarCycleActive becomes true 
 * and the radar cycle is started at the provided start time. When all 
 * radar cycles are done, #rfeApi_state_t.isRadarCycleActive returns to false.
 * 
 * \ingroup NIL
 */
void rfeApi_radarCycleStop( RFE_API_ERROR_FUNCTION_PARAMETER );

/**
 * \brief This function returns the rfe state.
 * 
 * \details This function returns the rfe state.
 * 
 * \pre Rfe must be initialized.
 * 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return rfeApi_state_t - Rfe state structure
 * 
 * \post Rfe state is returned
 * 
 * \ingroup NIL
 */
rfeApi_state_t rfeApi_getState( RFE_API_ERROR_FUNCTION_PARAMETER );


/**
 * \brief This function returns the rfe error information.
 * 
 * \details This function returns the rfe error information. This function
 * returns whether rfe has accepted or rejected the API call.
 * 
 * \pre NIL
 * 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return rfeApi_error_t - Rfe error type (undefined)
 * 
 * \post Rfe error type is returned
 * 
 * \ingroup NIL
 */
rfeApi_error_t rfeApi_getError( RFE_API_ERROR_FUNCTION_PARAMETER );


/**
 * \brief This function returns the rfe time.
 * 
 * \details This function returns the absolute rfe time since initialization
 * in [us]. The counter wrap around time is equal to 1 hour and 11 minutes. 
 * This function returns whether rfe has accepted or rejected the API call.
 * 
 * \pre #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return uint32_t - Absolute rfe time since intialization in [us]
 * 
 * \post Rfe time is returned
 * 
 * \ingroup NIL
 */
uint32_t rfeApi_getTime( RFE_API_ERROR_FUNCTION_PARAMETER );


/**
 * \brief This function returns information on the rfe
 * 
 * \details This function returns information on the rfe, such as the 
 * hardware and firmware variants as well as the versions. This function
 * returns whether rfe has accepted or rejected the API call.
 * 
 * \pre #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return rfeApi_info_t - Structure containing variant and version info
 * 
 * \post NIL
 * 
 * \ingroup NIL
 */
rfeApi_info_t rfeApi_getRfeInfo( RFE_API_ERROR_FUNCTION_PARAMETER );


#endif // !RFE_API_H

