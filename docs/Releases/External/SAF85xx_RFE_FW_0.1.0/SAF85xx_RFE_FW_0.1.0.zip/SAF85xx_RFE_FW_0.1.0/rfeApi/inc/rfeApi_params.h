/*
    Copyright 2021 NXP  
    NXP Confidential. This software is owned or controlled by NXP and may only be 
    used strictly in accordance with the applicable license terms. By expressly 
    accepting such terms or by downloading, installing, activating and/or otherwise
    using the software, you are agreeing that you have read, and that you agree to
    comply with and are bound by, such license terms.  If you do not agree to be 
    bound by the applicable license terms, then you may not retain, install, 
    activate or otherwise use the software.
 */


/******************************************************************************
 *   Project              : SAF85xx_RFE_FW
 *   Platform             : SAF85xx
 *****************************************************************************/

#ifndef RFE_API_PARAMS_H
#define RFE_API_PARAMS_H


/******************************************************************************
 *                              INCLUDES
 *****************************************************************************/

#include "rfeApi_error.h"
#include "rfeApi_types.h"


/******************************************************************************
 *                              TYPES
 *****************************************************************************/

/**
 * This macro defines the maximum number of chirps per chirp sequence
 */
#define RFE_API_CHIRP_COUNT_MAX                             ( 4096ul )

/**
 * This enumerated type defines the bist or calibration intervals
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_calibBistInterval_everyChirpSequence_e,
    rfeApi_calibBistInterval_everyRadarCycle_e,
    rfeApi_calibBistInterval_onceIn2RadarCycles_e,
    rfeApi_calibBistInterval_onceIn3RadarCycles_e,
    rfeApi_calibBistInterval_onceIn4RadarCycles_e
} rfeApi_calibBistInterval_t;

/**
 * This enumerated type defines the rfe power modes
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_powerMode_lowerPower_e,
    rfeApi_powerMode_active_e
} rfeApi_powerMode_t;

/**
 * This type defines which rfe components have dynamic power mode enabled/disabled  
 */
typedef uint8_t rfeApi_dynamicPowerEnable_t;
/** Enables dynamic power for component X */
#define RFE_API_DYNAMIC_POWER_ENABLE_COMPONENT_X            ( ( rfeApi_dynamicPowerEnable_t ) ( 1ul<<0 ) )
/** Enables dynamic power for component Y */
#define RFE_API_DYNAMIC_POWER_ENABLE_COMPONENT_Y            ( ( rfeApi_dynamicPowerEnable_t ) ( 1ul<<1 ) )

/**
 * This enumerated type defines when the chirp active IO signal is asserted
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_chirpActiveIoSignal_chirp_e,
    rfeApi_chirpActiveIoSignal_chirpSequence_e
} rfeApi_chirpActiveIoSignal_t;

/**
 * This type defines the CLK_IN and CLK_OUT parameters
 */
typedef uint8_t rfeApi_clkInOut_t;
/** Disables CLK_IN IO */
#define RFE_API_CLK_IN_OUT_CLK_IN_DISABLE                   ( ( rfeApi_clkInOut_t ) ( 1ul<<0 ) )
/** Enables CLK_IN IO */
#define RFE_API_CLK_IN_OUT_CLK_IN_ENABLE                    ( ( rfeApi_clkInOut_t ) ( 0ul<<0 ) )
/** Disables CLK_OUTP IO */
#define RFE_API_CLK_IN_OUT_CLK_OUTP_DISABLE                 ( ( rfeApi_clkInOut_t ) ( 1ul<<4 ) )
/** Enables CLK_OUTP IO */
#define RFE_API_CLK_IN_OUT_CLK_OUTP_ENABLE                  ( ( rfeApi_clkInOut_t ) ( 0ul<<4 ) )
/** Disables CLK_OUTN IO */
#define RFE_API_CLK_IN_OUT_CLK_OUTN_DISABLE                 ( ( rfeApi_clkInOut_t ) ( 1ul<<8 ) )
/** Enables CLK_OUTN IO */
#define RFE_API_CLK_IN_OUT_CLK_OUTN_ENABLE                  ( ( rfeApi_clkInOut_t ) ( 0ul<<8 ) )
/** Reduce CLK_OUT IO Drive level*/
#define RFE_API_CLK_IN_OUT_CLK_REDUCE_DRIVE_LEVEL           ( ( rfeApi_clkInOut_t ) ( 1ul<<12 ) )

/**
 * This enumerated type defines the PDC bandwidths
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_pdcBandwidth_wide_e,
    rfeApi_pdcBandwidth_narrow_e,
    rfeApi_pdcBandwidth_steep_narrow_e
} rfeApi_pdcBandwidth_t;

/**
 * This enumerated type defines the PDC bitwidths
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_pdcBitwidth_12bit_e,
    rfeApi_pdcBitwidth_14bit_e,
    rfeApi_pdcBitwidth_16bit_e
} rfeApi_pdcBitwidth_t;

/**
 * This type defines the data out destinations of the packer
 */
typedef uint8_t rfeApi_dataOutDest_t;
/** Enables data output to packet processor */
#define RFE_API_DATA_OUT_DEST_PACKET_PROCESSOR              ( ( rfeApi_dataOutDest_t ) ( 1ul<<0 ) )
/** Enables data output over CSI2 */
#define RFE_API_DATA_OUT_DEST_CSI2                          ( ( rfeApi_dataOutDest_t ) ( 1ul<<1 ) )

/**
 * This type defines the packer data out parameters
 */
typedef uint8_t rfeApi_dataOutConfig_t;
/** Enables interleaving of output data */
#define RFE_API_DATA_OUT_CONFIG_INTERLEAVING                ( ( rfeApi_dataOutConfig_t ) ( 1ul<<0 ) )
/** Enables header for output data */
#define RFE_API_DATA_OUT_CONFIG_HEADER                      ( ( rfeApi_dataOutConfig_t ) ( 1ul<<1 ) )
/** Enables footer for output data */
#define RFE_API_DATA_OUT_CONFIG_FOOTER                      ( ( rfeApi_dataOutConfig_t ) ( 1ul<<2 ) )
/** Enables long packet for output data */
#define RFE_API_DATA_OUT_CONFIG_LONG_PACKET                 ( ( rfeApi_dataOutConfig_t ) ( 1ul<<3 ) )

/**
 * This enumerated type defines the receiver saturation thresholds
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_rxSaturationThreshold_min13_05dB_e = 0ul,
    rfeApi_rxSaturationThreshold_min12_18dB_e = 1ul,
    rfeApi_rxSaturationThreshold_min11_31dB_e = 2ul,
    rfeApi_rxSaturationThreshold_min10_44dB_e = 3ul,
    rfeApi_rxSaturationThreshold_min9_57dB_e = 4ul,
    rfeApi_rxSaturationThreshold_min8_70dB_e = 5ul,
    rfeApi_rxSaturationThreshold_min7_83dB_e = 6ul,
    rfeApi_rxSaturationThreshold_min6_96dB_e = 7ul,
    rfeApi_rxSaturationThreshold_min6_09dB_e = 8ul,
    rfeApi_rxSaturationThreshold_min5_22dB_e = 9ul,
    rfeApi_rxSaturationThreshold_min4_35dB_e = 10ul,
    rfeApi_rxSaturationThreshold_min3_48dB_e = 11ul,
    rfeApi_rxSaturationThreshold_min2_61dB_e = 12ul,
    rfeApi_rxSaturationThreshold_min1_74dB_e = 13ul,
    rfeApi_rxSaturationThreshold_min0_87dB_e = 14ul,
    rfeApi_rxSaturationThreshold_0dB_e = 15ul
} rfeApi_rxSaturationThreshold_t;


/**
 * This macro defines the number of temperature sensors
 */
#define RFE_API_TEMPERATURE_SENSOR_COUNT                    ( 4ul )

/**
 * This enumerated type defines the temperature sensors
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_temperatureSensor_tx01_e = 0ul,
    rfeApi_temperatureSensor_tx23_e = 1ul,
    rfeApi_temperatureSensor_xo_e = 2ul,
    rfeApi_temperatureSensor_rx_e = 3ul
} rfeApi_temperatureSensorIndex_t;

/**
 * This type defines temperature as SQ6 in Celsius, 
 * SQ6 is a signed (2's complement) fixed point number format 
 * with 6 fractional bits. E.g. 1 deg Celsius = 0x0040
 */
typedef int16_t rfeApi_temperature_t;
#define RFE_API_TEMPERATURE_1_DEG_CELSIUS                   ( ( rfeApi_temperature_t ) ( 1ul<<6 ) )

/**
 * This macro defines the maximum number of chirp sequence configs
 */
#define RFE_API_CHIRP_SEQUENCE_CONFIGS_MAX                  ( 4ul )

/**
 * This enumerated type defines indices for the chirp sequence configuration array
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_chirpSequenceConfigIndex_0_e = 0ul,
    rfeApi_chirpSequenceConfigIndex_1_e = 1ul,
    rfeApi_chirpSequenceConfigIndex_2_e = 2ul,
    rfeApi_chirpSequenceConfigIndex_3_e = 3ul
} rfeApi_chirpSequenceConfigIndex_t;

/**
 * This macro defines the maximum number of configurable profiles
 */
#define RFE_API_CHIRP_PROFILES_MAX                          ( 8ul )

/**
 * This enumerated type defines the chirp profile indices
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_chirpProfileIndex_0_e = 0ul,
    rfeApi_chirpProfileIndex_1_e = 1ul,
    rfeApi_chirpProfileIndex_2_e = 2ul,
    rfeApi_chirpProfileIndex_3_e = 3ul,
    rfeApi_chirpProfileIndex_4_e = 4ul,
    rfeApi_chirpProfileIndex_5_e = 5ul,
    rfeApi_chirpProfileIndex_6_e = 6ul,
    rfeApi_chirpProfileIndex_7_e = 7ul
} rfeApi_chirpProfileIndex_t;

/**
 * This types defines a selection of chirp profiles
 */
typedef uint8_t rfeApi_chirpProfilesSelect_t;
#define RFE_API_CHIRP_PROFILES_SELECT_0                     ( ( rfeApi_chirpProfilesSelect_t ) ( 1ul<<0 ) )
#define RFE_API_CHIRP_PROFILES_SELECT_1                     ( ( rfeApi_chirpProfilesSelect_t ) ( 1ul<<1 ) )
#define RFE_API_CHIRP_PROFILES_SELECT_2                     ( ( rfeApi_chirpProfilesSelect_t ) ( 1ul<<2 ) )
#define RFE_API_CHIRP_PROFILES_SELECT_3                     ( ( rfeApi_chirpProfilesSelect_t ) ( 1ul<<3 ) )
#define RFE_API_CHIRP_PROFILES_SELECT_4                     ( ( rfeApi_chirpProfilesSelect_t ) ( 1ul<<4 ) )
#define RFE_API_CHIRP_PROFILES_SELECT_5                     ( ( rfeApi_chirpProfilesSelect_t ) ( 1ul<<5 ) )
#define RFE_API_CHIRP_PROFILES_SELECT_6                     ( ( rfeApi_chirpProfilesSelect_t ) ( 1ul<<6 ) )
#define RFE_API_CHIRP_PROFILES_SELECT_7                     ( ( rfeApi_chirpProfilesSelect_t ) ( 1ul<<7 ) )

/**
 * This macro defines the maximum chirp profile sequence length
 */
#define RFE_API_CHIRP_PROFILE_SEQUENCE_LENGTH_MAX           ( 8ul )


/**
 * This enumerated type defines the effective sampling frequency of the chirp
 * Effective means the sampling frequency after decimation, i.e. of the output samples
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_effectiveSamplingFrequency_40MHz_e,
    rfeApi_effectiveSamplingFrequency_20MHz_e,
    rfeApi_effectiveSamplingFrequency_10MHz_e,
    rfeApi_effectiveSamplingFrequency_8_89MHz_e,
    rfeApi_effectiveSamplingFrequency_8MHz_e,
    rfeApi_effectiveSamplingFrequency_6_67MHz_e,
    rfeApi_effectiveSamplingFrequency_5MHz_e
} rfeApi_effectiveSamplingFrequency_t;

/**
 * This macro defines the number of nano seconds that corresponds to a single time tick
 */
#define RFE_API_NS_PER_TIME_TICK                            ( 25ul )

/**
 * This enumerated type defines slope directions of a chirp
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_chirpSlopeDirection_falling_e,
    rfeApi_chirpSlopeDirection_rising_e
} rfeApi_chirpSlopeDirection_t;

/**
 * This enumerated type defines a selection of voltage-controlled oscillators
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_chirpGenVco_1GHz_e,
    rfeApi_chirpGenVco_4GHz_e
} rfeApi_chirpGenVco_t;

/**
 * This macro defines the number of transmitters
 */
#define RFE_API_TX_COUNT                                    ( 4ul )

/**
 * This enumerated type defines the indices of the transmitters
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_txIndex_0_e = 0ul,
    rfeApi_txIndex_1_e = 1ul,
    rfeApi_txIndex_2_e = 2ul,
    rfeApi_txIndex_3_e = 3ul
} rfeApi_txIndex_t;

/**
 * This type defines a selection of transmitters
 */
typedef uint8_t rfeApi_txSelect_t;
#define RFE_API_TX_SELECT_0                                 ( (rfeApi_txSelect_t) ( 1ul<<0 ) )
#define RFE_API_TX_SELECT_1                                 ( (rfeApi_txSelect_t) ( 1ul<<1 ) )
#define RFE_API_TX_SELECT_2                                 ( (rfeApi_txSelect_t) ( 1ul<<2 ) )
#define RFE_API_TX_SELECT_3                                 ( (rfeApi_txSelect_t) ( 1ul<<3 ) )

/**
 * This macro defines 1 dB transmitter output power
 */
#define RFE_API_TX_POWER_1_DB                               ( 10ul )

/**
 * This type defines the phase rotation as Q7 for 360 degrees, 45 deg = 0x10
 */
typedef uint8_t rfeApi_phaseRotation_t;
#define RFE_API_PHASE_ROTATION_360_DEG                      ( ( rfeApi_phaseRotation_t ) ( 1ul<<7 ) )

/**
 * This enumerated type defines the time reference for the tx enable and phase rotation enable
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_txEnableReferenceTime_startOfDwellTime_e,
    rfeApi_txEnableReferenceTime_startOfSettleTime_e
} rfeApi_txEnableReferenceTime_t;

/**
 * This macro defines the number of receivers
 */
#define RFE_API_RX_COUNT                                    ( 4ul )

/**
 * This enumerated type defines the indices of the receivers
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_rxIndex_0_e = 0ul,
    rfeApi_rxIndex_1_e = 1ul,
    rfeApi_rxIndex_2_e = 2ul,
    rfeApi_rxIndex_3_e = 3ul
} rfeApi_rxIndex_t;

/**
 * This type defines a selection of receivers
 */
typedef uint8_t rfeApi_rxSelect_t;
#define RFE_API_RX_SELECT_0                                 ( (rfeApi_rxSelect_t) ( 1ul<<0 ) )
#define RFE_API_RX_SELECT_1                                 ( (rfeApi_rxSelect_t) ( 1ul<<1 ) )
#define RFE_API_RX_SELECT_2                                 ( (rfeApi_rxSelect_t) ( 1ul<<2 ) )
#define RFE_API_RX_SELECT_3                                 ( (rfeApi_rxSelect_t) ( 1ul<<3 ) )

/**
 * This enumaration type defines the receiver gains
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_rxGain_25dB_e,
    rfeApi_rxGain_28dB_e,
    rfeApi_rxGain_31dB_e,
    rfeApi_rxGain_34dB_e,
    rfeApi_rxGain_37dB_e,
    rfeApi_rxGain_40dB_e,
    rfeApi_rxGain_43dB_e,
    rfeApi_rxGain_46dB_e
} rfeApi_rxGain_t;

/**
 * This enumaration type defines the receiver high-pass filter cut-off frequencies
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_rxHpfCutOffFrequency_200kHz_e,
    rfeApi_rxHpfCutOffFrequency_300kHz_e,
    rfeApi_rxHpfCutOffFrequency_400kHz_e,
    rfeApi_rxHpfCutOffFrequency_800kHz_e,
    rfeApi_rxHpfCutOffFrequency_1600kHz_e,
    rfeApi_rxHpfCutOffFrequency_3200kHz_e,
    rfeApi_rxHpfCutOffFrequency_6400kHz_e
} rfeApi_rxHpfCutOffFrequency_t;

/**
 * This enumaration type defines the receiver low-pass filter cut-off frequencies
 */
typedef enum RFE_API_ATTRIBUTE_PACKED
{
    rfeApi_rxLpfCutOffFrequency_10MHz_e,
    rfeApi_rxLpfCutOffFrequency_15MHz_e,
    rfeApi_rxLpfCutOffFrequency_20MHz_e,
    rfeApi_rxLpfCutOffFrequency_25MHz_e,
    rfeApi_rxLpfCutOffFrequency_30MHz_e,
    rfeApi_rxLpfCutOffFrequency_40MHz_e
} rfeApi_rxLpfCutOffFrequency_t;

/**
 * This type defines an address to system memory
 */
typedef uint32_t rfeApi_sysMemAddress_t;

/**
 * This enumerated type defines a selection of dynamic parameters
 */
typedef uint16_t rfeApi_dynParamsSelect_t;
#define RFE_API_DYN_PARAMS_SELECT_CHIRP_PROFILE             ( (rfeApi_dynParamsSelect_t) ( 1ul<<0 ) )
#define RFE_API_DYN_PARAMS_SELECT_TX0_PHASE_ROTATION        ( (rfeApi_dynParamsSelect_t) ( 1ul<<1 ) )
#define RFE_API_DYN_PARAMS_SELECT_TX1_PHASE_ROTATION        ( (rfeApi_dynParamsSelect_t) ( 1ul<<2 ) )
#define RFE_API_DYN_PARAMS_SELECT_TX2_PHASE_ROTATION        ( (rfeApi_dynParamsSelect_t) ( 1ul<<3 ) )
#define RFE_API_DYN_PARAMS_SELECT_TX3_PHASE_ROTATION        ( (rfeApi_dynParamsSelect_t) ( 1ul<<4 ) )
#define RFE_API_DYN_PARAMS_SELECT_TX_TRANSMISSION_ENABLE    ( (rfeApi_dynParamsSelect_t) ( 1ul<<5 ) )
#define RFE_API_DYN_PARAMS_SELECT_TX_ENABLE                 ( (rfeApi_dynParamsSelect_t) ( 1ul<<6 ) )
#define RFE_API_DYN_PARAMS_SELECT_DWELL_TIME_TICKS          ( (rfeApi_dynParamsSelect_t) ( 1ul<<7 ) )
#define RFE_API_DYN_PARAMS_SELECT_SETTLE_TIME_TICKS         ( (rfeApi_dynParamsSelect_t) ( 1ul<<8 ) )
#define RFE_API_DYN_PARAMS_SELECT_CIT_TICKS                 ( (rfeApi_dynParamsSelect_t) ( 1ul<<9 ) )
#define RFE_API_DYN_PARAMS_SELECT_ALL                       ( (rfeApi_dynParamsSelect_t) ( 0x7FFul ) )


/******************************************************************************
 *                              FUNCTIONS
 *****************************************************************************/
 
 /**
 * \brief This function returns the scheduled absolute start time of the next radar cycle
 * 
 * \details This function returns the scheduled absolute start time of the next 
 * radar cycle according to the rfe time. This function returns whether rfe
 * has accepted or rejected the API call.
 * 
 * \pre 
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * - #rfeApi_state_t.isRadarCycleActive is true 
 * - The radar cycle is not the last in the sequence of triggered radar cycles.
 * 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return uint32_t - Absolute start time of the next scheduled radar cycle in [us]
 * 
 * \post NIL
 * 
 * \ingroup NIL
 */
uint32_t rfeApi_getNextRadarCycleStartTime( RFE_API_ERROR_FUNCTION_PARAMETER );

/**
 * \brief This function updates the start time of the next radar cycle
 * 
 * \details This function updates the absolute start time of the next radar cycle
 * according to the rfe time. This function returns whether rfe has accepted
 * or rejected the API call.
 * 
* \pre 
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * - #rfeApi_state_t.isRadarCycleActive must be true 
 * - The radar cycle must not be the last in the sequence of triggered radar cycles.
 * 
 * \param [in]      startTime - Absolute start time of the next radar cycle in [us].
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post Next radar cycle starts at the given start time.
 * 
 * \ingroup NIL
 */
void rfeApi_setNextRadarCycleStartTime(
    uint32_t startTime,
    RFE_API_ERROR_FUNCTION_PARAMETER
);

/**
 * \brief This function updates the start time of a chirp sequence for each radar cycle
 * 
 * \details This function updates the start time of the selected chirp sequence
 * for each radar cycle from now onward that was configured using rfeApi_config(). 
 * The start time is relative to the radar cycle start time. The chirp sequence 
 * can be selected by \p chirpSequenceIndex. It updates that index of the
 * #rfeApi_radarCycleParams_t.chirpSequenceStartTimeOffset array. This function 
 * returns whether rfe has accepted or rejected the API call.
 * 
 * \pre 
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * - #rfeApi_state_t.isRadarCycleActive must be true
 * 
 * \param [in]      chirpSequenceIndex - The index of the chirp sequence 
 *                  to update.
 * \param [in]      startTimeOffset - Start time offset of the selected chirp 
 *                  sequence in [us] relative to the the radar cycle start time.
 *                  See also #rfeApi_radarCycleParams_t.chirpSequenceStartTimeOffset.
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post Next radar cycle starts at the given start time.
 * 
 * \ingroup NIL
 */
void rfeApi_setChirpSequenceStartTimeOffset(
    uint8_t chirpSequenceIndex,
    uint32_t startTimeOffset,
    RFE_API_ERROR_FUNCTION_PARAMETER
);

/**
 * \brief This function updates what chirp profile(s) is applied to a chirp sequence.
 * 
 * \details This function updates what chirp profile(s) is applied to a chirp sequence,
 * that was configured using rfeApi_config(). The chirp sequence config can be selected by
 * \p chirpSequenceConfigIndex. It updates the #rfeApi_chirpSequenceParams_t.chirpProfileSequence
 * and #rfeApi_chirpSequenceParams_t.chirpProfileSequenceLength parameters of this config.
 * A single chirp profile can be applied to all chirps in the chirp sequence, or a profile sequence
 * can be defined that is applied repetitively, e.g. for a interleaved multi-mode chirp sequence.
 * See the above-mentioned struct members for more details on their usage and examples.
 * This function returns whether rfe has accepted or rejected the API call.
 * 
 * \pre 
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * - #rfeApi_state_t.isConfigured must be true.
 * 
 * \param [in]      chirpSequenceConfigIndex - The index of the chirp sequence 
 *                  configuration to update.
 * \param [in]      pChirpProfileSequence - Pointer to a profile sequence array.
 *                  This profile sequence is repetitvely applied to all 
 *                  the chirps in the chirp sequence. The sequence/repetition length
 *                  is variable and can be defined using \p chirpProfileSequenceLength. 
 *                  The entries in this array beyond the sequence length is ignored.
 *                  See #rfeApi_chirpSequenceParams_t.chirpProfileSequence for examples.
 * \param [in]      chirpProfileSequenceLength - The sequence/repetition length for 
 *                  the chirp profile sequence. This corresponds to the number of entries 
 *                  in the \p chirpProfileSequence array that is used.
 *                  See #rfeApi_chirpSequenceParams_t.chirpProfileSequenceLength for more details.
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post The chirp profile sequence is updated for following chirp sequences
 * using the selected chirp sequence configuration.
 * 
 * \ingroup NIL
 */
void rfeApi_setChirpProfileSequence(
    rfeApi_chirpSequenceConfigIndex_t chirpSequenceConfigIndex,
    rfeApi_chirpProfileIndex_t *pChirpProfileSequence,
    uint8_t chirpProfileSequenceLength,
    RFE_API_ERROR_FUNCTION_PARAMETER
);

/**
 * \brief This function updates a dynamic table
 * 
 * \details This function updates a dynamic table. It can update a full table or 
 * it can update the sequences of selected dynamic parameters (i.e. table rows).
 * This function returns whether rfe has accepted  or rejected the API call.
 * 
 * \pre 
 * -#rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * -#rfeApi_state_t.isConfigured must be true.
 * 
 * \param [in]      dynamicTableIndex - The index of the dynamic table to update.
 * \param [in]      paramsSelect - The selection of dynamic parameters to update.
 *                  Use #RFE_API_DYN_PARAMS_SELECT_ALL to update the full table.
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post The selected dynamic table is updated.
 * 
 * \ingroup NIL
 */
void rfeApi_updateDynamicTable(
    uint8_t dynamicTableIndex,
    rfeApi_dynParamsSelect_t paramsSelect,
    RFE_API_ERROR_FUNCTION_PARAMETER
);

/**
 * \brief This function updates the center frequency for a given chirp profile
 * 
 * \details This function updates the center frequency for a given chirp profile,
 * that was configured using rfeApi_config(). The chirp profile can be selected by
 * \p chirpProfileIndex. It updates the #rfeApi_chirpProfileParams_t.centerFrequency
 * parameter of this profile. This function returns whether rfe has accepted
 * or rejected the API call.
 * 
 * \pre 
 * -#rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * -#rfeApi_state_t.isConfigured must be true.
 * 
 * \param [in]      chirpProfileIndex - The index of the chirp profile
 * \param [in]      centerFrequency - The center frequency in [kHz].
 *                  See also #rfeApi_chirpProfileParams_t.centerFrequency.
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post The center frequency of the given chirp profile is updated.
 * 
 * \ingroup NIL
 */
void rfeApi_setCenterFrequency(
    rfeApi_chirpProfileIndex_t chirpProfileIndex,
    uint32_t centerFrequency,
    RFE_API_ERROR_FUNCTION_PARAMETER
);

/**
 * \brief This function updates the effective chirp bandwidth for a given chirp profile
 * 
 * \details This function updates the effective chirp bandwidth for a given chirp profile,
 * that was configured using rfeApi_config(). The chirp profile can be selected by
 * \p chirpProfileIndex. It updates the #rfeApi_chirpProfileParams_t.effectiveChirpBandwidth
 * parameter of this profile. This function returns whether rfe has accepted or 
 * rejected the API call.
 * 
 * \pre 
 * -#rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * -#rfeApi_state_t.isConfigured must be true.
 * 
 * \param [in]      chirpProfileIndex - The index of the chirp profile
 * \param [in]      effectiveChirpBandwidth - The effective chirp bandwidth in [kHz].
 *                  See also #rfeApi_chirpProfileParams_t.effectiveChirpBandwidth.
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post The effective chirp bandwidth of the given chirp profile is updated.
 * 
 * \ingroup NIL
 */
void rfeApi_setEffectiveChirpBandwidth(
    rfeApi_chirpProfileIndex_t chirpProfileIndex,
    uint32_t effectiveChirpBandwidth,
    RFE_API_ERROR_FUNCTION_PARAMETER
);

/**
 * \brief This function updates the chirp interval time for a given chirp profile
 * 
 * \details This function updates the chirp interval time for a given chirp profile,
 * that was configured using rfeApi_config(). The chirp profile can be selected by
 * \p chirpProfileIndex. It updates the #rfeApi_chirpProfileParams_t.chirpIntervalTimeTicks
 * parameter of this profile. This function returns whether rfe has accepted 
 * or rejected the API call.
 * 
 * \pre 
 * -#rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * -#rfeApi_state_t.isConfigured must be true.
 * 
 * \param [in]      chirpProfileIndex - The index of the chirp profile
 * \param [in]      chirpIntervalTimeTicks - The chirp interval time in [25ns] ticks.
 *                  See also #rfeApi_chirpProfileParams_t.chirpIntervalTimeTicks.
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post The chirp interval time of the given chirp profile is updated.
 * 
 * \ingroup NIL
 */
void rfeApi_setChirpIntervalTime(
    rfeApi_chirpProfileIndex_t chirpProfileIndex,
    uint32_t chirpIntervalTimeTicks,
    RFE_API_ERROR_FUNCTION_PARAMETER
);


#endif // !RFE_API_PARAMS_H

