/*
    Copyright 2021 NXP  
    NXP Confidential. This software is owned or controlled by NXP and may only be 
    used strictly in accordance with the applicable license terms. By expressly 
    accepting such terms or by downloading, installing, activating and/or otherwise
    using the software, you are agreeing that you have read, and that you agree to
    comply with and are bound by, such license terms.  If you do not agree to be 
    bound by the applicable license terms, then you may not retain, install, 
    activate or otherwise use the software.
 */


/******************************************************************************
 *   Project              : SAF85xx_RFE_FW
 *   Platform             : SAF85xx
 *****************************************************************************/

#ifndef RFE_API_CHIRP_H
#define RFE_API_CHIRP_H


/******************************************************************************
 *                              INCLUDES
 *****************************************************************************/

#include "rfeApi_error.h"
#include "rfeApi_params.h"
#include "rfeApi_types.h"


/******************************************************************************
 *                              TYPES
 *****************************************************************************/

/**
 * This structure contains the chirp profile parameters.
 * These parameters are applied on the chirps that use this profile
 */
typedef struct RFE_API_ATTRIBUTE_PACKED
{
    /** 
     * The effective sampling frequency of the chirp. Here 'effective' indicates
     * that this is the sampling frequency after decimation, i.e. of the output samples.
     */
    rfeApi_effectiveSamplingFrequency_t effectiveSamplingFrequency;
    /** The chirp interval time in multiple of 25 [ns] clock ticks */
    uint32_t chirpIntervalTimeTicks;
    /** The chirp dwell time in multiple of 25 [ns] clock ticks */
    uint16_t dwellTimeTicks;
    /** The chirp settle time in multiple of 25 [ns] clock ticks */
    uint16_t settleTimeTicks;
    /** The chirp acquisition time in multiple of 25 [ns] clock ticks */
    uint16_t acquisitionTimeTicks;
    /** The chirp jumpback time in multiple of 25 [ns] clock ticks */
    uint8_t jumpbackTimeTicks;
    /** The chirp reset time in multiple of 25 [ns] clock ticks */
    uint8_t resetTimeTicks;
    /** 
     * The center frequency of the chirp in [kHz] 
     */
    uint32_t centerFrequency;
    /** 
     * The effective bandwidth in [kHz]. This is the bandwidth used 
     * during the chirp acquisition. A bandwidth of 0 results in
     * a 'chirp' with constant frequency.
     */
    uint32_t effectiveChirpBandwidth;
    /** Selection of the VCO that the chirp generator uses to generate the chirp */
    rfeApi_chirpGenVco_t chirpGenVcoSelect;
    /** Selection of the direction of the chirp slope: rising or falling */
    rfeApi_chirpSlopeDirection_t chirpSlopeDirection;
    /** Selection of transmitters that are enabled during the chirp. */
    rfeApi_txSelect_t txEnable;
    /** Selection of transmitters that transmit the chirp. */
    rfeApi_txSelect_t txTransmissionEnable;
    /** Output power of the transmitters in 0.1 [dBm] */
    uint8_t txPower;
    /** Phase rotation for each transmitter */
    rfeApi_phaseRotation_t txPhaseRotation[RFE_API_TX_COUNT];
    /** 
     * Selection of the reference time to enable the transmitters and 
     * apply the phase rotation after a fixed delay, which can 
     * be configured by the #txEnableTimeOffset parameter. 
    */
    rfeApi_txEnableReferenceTime_t txEnableReferenceTime;
    /** 
     * The time offset relative to the reference time (#txEnableReferenceTime) after 
     * which the transmitter is enabled and the phase rotation applied. 
     * Offset is in multiple of 25 [ns] clock ticks
     */
    uint16_t txEnableTimeOffset;
    /** Selection of receivers that are enabled during the chirp. */
    rfeApi_rxSelect_t rxEnable;
    /** The gain of the receivers */
    rfeApi_rxGain_t rxGain;
    /** The cut-off frequency of receivers' high-pass filters */
    rfeApi_rxHpfCutOffFrequency_t rxHpfCutOffFrequency;
    /** The cut-off frequency of receivers' low-pass filters */
    rfeApi_rxLpfCutOffFrequency_t rxLpfCutOffFrequency;
    /** The CSI-2 virtual channel applied on data for the chirps using this profile */
    uint8_t csi2VirtualChannel;
} rfeApi_chirpProfileParams_t;


/**
 * This structure contains the chirp sequence parameters.
 */
typedef struct RFE_API_ATTRIBUTE_PACKED
{
    /** The number of chirps within the chirp sequence */
    uint16_t chirpCount;
    /** 
     * The profile sequence that is repetitvely applied to all the chirps in the chirp sequence. 
     * The sequence/repetition length is variable and can be defined using #chirpProfileSequenceLength. 
     * The entries in this array beyond the sequence length is ignored.
     * 
     * - Example 1: Single-mode chirp sequence: 0-0-0-0-0-0-.. \n
     *   chirpProfileSequence = {#rfeApi_chirpProfileIndex_0_e}; \n
     *   chirpProfileSequenceLength = 1;
     * - Example 2: Single-mode chirp sequence: 1-1-1-1-1-1-.. \n
     *   chirpProfileSequence = {#rfeApi_chirpProfileIndex_1_e}; \n
     *   chirpProfileSequenceLength = 1;
     * - Example 3: Triple-mode interleaved chirp sequence 0-1-2-0-1-2-.. \n
     *   chirpProfileSequence = {#rfeApi_chirpProfileIndex_0_e,#rfeApi_chirpProfileIndex_1_e,#rfeApi_chirpProfileIndex_2_e}; \n
     *   chirpProfileSequenceLength = 3;
     */
    rfeApi_chirpProfileIndex_t chirpProfileSequence[RFE_API_CHIRP_PROFILE_SEQUENCE_LENGTH_MAX];
    /** 
     * The sequence/repetition length for the chirp profile sequence. This corresponds
     * to the number of entries in the #chirpProfileSequence array that is used.
     * See that parameter for more details. 
     * The minimum length is 1, maximum is #RFE_API_CHIRP_PROFILE_SEQUENCE_LENGTH_MAX.
     */
    uint8_t chirpProfileSequenceLength;
    /**
     * The number of times a chirp profile is repeated 
     * before proceeding to the next entry in the chirp profile sequence.
     * For a #chirpProfileSequenceLength of 1, this parameter has no effect.
     * Default: 1
     *
     * - Example 1: Single repitition for example 3 of #chirpProfileSequence \n
     *   chirpProfileRepetitionCount = 1; \n
     *   Resulting chirp profile sequence: 0-1-2-0-1-2-..
     * - Example 2: Two times repitition for example 3 of #chirpProfileSequence \n
     *   chirpProfileRepetitionCount = 2; \n
     *   Resulting chirp profile sequence: 0-0-1-1-2-2-0-0-1-1-2-2-..
     */
    uint8_t chirpProfileRepetitionCount;
    /** 
     * Indicates whether the dynamic updates, i.e. parameter updates per chirp,
     * are enabled or disabled.
     */
    bool isDynamicUpdatesEnabled;
    /** 
     * The index of the dynamic table to be used for the chirp sequence. This 
     * table contains the values for each dynamic parameter for each chirp.
     */
    uint8_t dynamicTableIndex;
} rfeApi_chirpSequenceParams_t;


/******************************************************************************
 *                              FUNCTIONS
 *****************************************************************************/
 
 /**
 * \brief This function initializes a chirp sequence as by the given config
 * 
 * \details This function initializes a chirp sequence as by the given config, 
 * which is used for chirp sequences started afterwards. This function
 * cannot be used  during an acitve radar cycle the radar cycle. In an active 
 * radar cycle, it is handled in the rfe internally. This function 
 * returns whether rfe has accepted or rejected the API call.
 * 
 * \pre 
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e 
 * - #rfeApi_state_t.isRadarCycleActive must be false
 * 
 * \param [in]      chirpSequenceConfigIndex - Index of the chirp sequence config
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post #rfeApi_state_t.functionalState remains #rfeApi_functionalState_idle_e. 
 * The povided chirp sequence is initialized and is used for the next API-started 
 * chirp sequence.
 * 
 * \ingroup NIL
 */
void rfeApi_chirpSequenceInit(
    rfeApi_chirpSequenceConfigIndex_t chirpSequenceConfigIndex,
    RFE_API_ERROR_FUNCTION_PARAMETER
);


/******************************************************************************
 *                              FUNCTIONS
 *****************************************************************************/
 
 /**
 * \brief This function starts rfe calibration
 * 
 * \details This function starts the rfe calibration, calibration must be
 * executed before a chirp sequence. This function cannot be used during an
 * active radar cycle. In an active radar cycle, calibration is started 
 * from the rfe internally. This function returns whether rfe has accepted 
 * or rejected the API call.
 * 
 * \pre 
 * - #rfeApi_state_t.isConfigured must be true
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * - A chirp sequence config must be initialized
 * - #rfeApi_state_t.isRadarCycleActive must be false
 * 
 * \param [in]      chirpProfiles - Selection of chirp profiles to calibrate
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post #rfeApi_state_t.functionalState becomes #rfeApi_functionalState_calibration_e
 * The rfe is calibrated and when done #rfeApi_state_t.functionalState 
 * returns to #rfeApi_functionalState_idle_e
 * 
 * \ingroup NIL
 */
void rfeApi_calibrationStart(
    rfeApi_chirpProfilesSelect_t chirpProfiles,
    RFE_API_ERROR_FUNCTION_PARAMETER
);


 /**
 * \brief This function starts a configured chirp sequence
 * 
 * \details This function starts a chirp sequence, according to the initialized 
 * configuration at the given start time or as a soon as possible. This
 * function cannot be used during an active radar cycle. In an active radar
 * cycle, the chirp sequence is started from the rfe internally. This 
 * function returns whether rfe has accepted or rejected the API call.
 * 
 * \pre 
 * - #rfeApi_state_t.isConfigured must be true
 * - Rfe must be calibrated
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * - A chirp sequence config must be initialized 
 * - #rfeApi_state_t.isRadarCycleActive must be false
 * 
 * \param [in]      isScheduled - If true, radar cycle is started at startTime.
 *                  If false the radar cycle is started as soon as possible
 * \param [in]      startTime - The absolute start time in [us] of the chirp 
 *                  sequence according to the rfe time.
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post #rfeApi_state_t.functionalState becomes #rfeApi_functionalState_chirpSequence_e
 * The chirp sequence is executed and when done #rfeApi_state_t.functionalState returns 
 * to #rfeApi_functionalState_idle_e.
 * 
 * \ingroup NIL
 */
void rfeApi_chirpSequenceStart(
    bool isScheduled,
    uint32_t startTime,
    RFE_API_ERROR_FUNCTION_PARAMETER
);


 /**
 * \brief This function starts the built-in-self-tests
 * 
 * \details This function starts the built-in-self-tests. This function cannot
 * be used during an active radar cycle. In an active radar cycle, bist is
 * handled from the rfe internally. This function returns whether rfe has 
 * accepted or rejected the API call.
 * 
 * \pre
 * - #rfeApi_state_t.isConfigured must be true
 * - Rfe must be calibrated
 * - #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * - A chirp sequence config must be initialized 
 * - #rfeApi_state_t.isRadarCycleActive must be false
 * 
 * \param [in]      chirpProfiles - Selection of chirp profiles to consider for bist
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post #rfeApi_state_t.functionalState becomes #rfeApi_functionalState_bist_e
 * The bist sequence is executed and when done #rfeApi_state_t.functionalState returns 
 * to #rfeApi_functionalState_idle_e.
 * 
 * \ingroup NIL
 */
void rfeApi_bistStart(
    rfeApi_chirpProfilesSelect_t chirpProfiles,
    RFE_API_ERROR_FUNCTION_PARAMETER
);


#endif // !RFE_API_CHIRP_H

