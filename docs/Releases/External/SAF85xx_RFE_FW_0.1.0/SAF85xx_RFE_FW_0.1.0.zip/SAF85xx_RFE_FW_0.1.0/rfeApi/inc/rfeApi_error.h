/*
    Copyright 2021 NXP  
    NXP Confidential. This software is owned or controlled by NXP and may only be 
    used strictly in accordance with the applicable license terms. By expressly 
    accepting such terms or by downloading, installing, activating and/or otherwise
    using the software, you are agreeing that you have read, and that you agree to
    comply with and are bound by, such license terms.  If you do not agree to be 
    bound by the applicable license terms, then you may not retain, install, 
    activate or otherwise use the software.
 */


/******************************************************************************
 *   Project              : SAF85xx_RFE_FW
 *   Platform             : SAF85xx
 *****************************************************************************/

#ifndef RFE_API_ERROR_H
#define RFE_API_ERROR_H


/******************************************************************************
 *                              INCLUDES
 *****************************************************************************/



/******************************************************************************
 *                              TYPES
 *****************************************************************************/

/**
 * API Error codes.
 */
typedef enum
{
    /** No error occurred */
    rfeApi_error_none_e = 0ul,
    /** Undefined error */
    rfeApi_error_undefined_e = 1ul,
    /** Error because rfe is busy */
    rfeApi_error_rfeBusy_e = 2ul,
    /** Error because rfe is unresponsive */
    rfeApi_error_rfeUnresponsive_e = 3ul,
    /** Error because rfe was already initialized */
    rfeApi_error_rfeAlreadyInitialized_e = 4ul,
    /** Error because operation is not allowed when rfe is unconfigured */
    rfeApi_error_rfeUnconfigured_e = 5ul,
    /** Error because operation is not allowed while radar cycle is active */
    rfeApi_error_radarCycleActive_e = 7ul,
    /** Error because operation is not allowed while radar cycle is inactive */
    rfeApi_error_radarCycleInactive_e = 8ul,
    /** Error because operation is not allowed because RFE is in error state */
    rfeApi_error_rfeInErrorState_e = 9ul,
    /** Error due to invalid pointer */
    rfeApi_error_invalidPointer_e = 10ul,
    /** Error because pointer is not shared in memory  */
    rfeApi_error_pointerNotInSharedMemory_e = 11ul,
    /** Error because parameter is out of allowed range */
    rfeApi_error_parameterOutOfRange_e = 12ul,
    /** Error because operation is not allowed when rfe is unitialized */
    rfeApi_error_uninitialized_e = 32ul,
    /** Error because of an internal rfe error happened, check safetyState and rfeApi_getError */
    rfeApi_error_rfeInternal_e = ( 1ul<<13 )
} rfeApi_error_t;

/**
 * \brief Creates the error variable required by the error handling system.
 */
#define RFE_API_ERROR_CREATE                            rfeApi_error_t rfeApi___error___value = rfeApi_error_none_e; rfeApi_error_t *rfeApi___error___pointer = &rfeApi___error___value;

/**
 * \brief This macro should be added as the last parameter in the definition of an error handling aware function.
 */
#define RFE_API_ERROR_FUNCTION_PARAMETER                rfeApi_error_t* rfeApi___error___pointer

/**
 * \brief This macro should be used as the last argument when calling an error handling aware function.
 */
#define RFE_API_ERROR_FUNCTION_ARGUMENT                 rfeApi___error___pointer

/**
 * \brief Clears the error variable (sets it to rfeApi_error_none_e).
 */
#define RFE_API_ERROR_CLEAR                             { *rfeApi___error___pointer = rfeApi_error_none_e; }

/**
 * \brief Sets the error variable to the specified rfeApi_error_t enumeration constant.
 */
#define RFE_API_ERROR_SET( err )                        { *rfeApi___error___pointer = err; }

/**
 * \brief Gets the current error value (e.g., rfeApi_error_none_e).
 */
#define RFE_API_ERROR_GET                               ( *rfeApi___error___pointer )

/**
 * \brief Evaluates to true if the current error value is rfeApi_error_none_e. Otherwise, evaluates to false.
 */
#define RFE_API_ERROR_IS_NO_ERROR                       ( rfeApi_error_none_e == *rfeApi___error___pointer )

/**
 * \brief Evaluates to true if the current error value is not rfeApi_error_none_e. Otherwise, evaluates to false.
 */
#define RFE_API_ERROR_IS_ERROR                          ( rfeApi_error_none_e != *rfeApi___error___pointer )

/**
 * \brief The guarded code block is only executed if the current error value is rfeApi_error_none_e.
 */
#define RFE_API_ERROR_GUARD                             if ( rfeApi_error_none_e != *rfeApi___error___pointer ) { /* skip due to error*/ } else


#endif // !RFE_API_ERROR_H

