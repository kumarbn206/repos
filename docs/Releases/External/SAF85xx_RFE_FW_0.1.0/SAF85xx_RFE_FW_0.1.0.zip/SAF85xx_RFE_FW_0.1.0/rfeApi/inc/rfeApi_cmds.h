/*
    Copyright 2021 NXP  
    NXP Confidential. This software is owned or controlled by NXP and may only be 
    used strictly in accordance with the applicable license terms. By expressly 
    accepting such terms or by downloading, installing, activating and/or otherwise
    using the software, you are agreeing that you have read, and that you agree to
    comply with and are bound by, such license terms.  If you do not agree to be 
    bound by the applicable license terms, then you may not retain, install, 
    activate or otherwise use the software.
 */


/******************************************************************************
 *   Project              : SAF85xx_RFE_FW
 *   Platform             : SAF85xx
 *****************************************************************************/

#ifndef RFE_API_CMDS_H
#define RFE_API_CMDS_H


/******************************************************************************
 *                              INCLUDES
 *****************************************************************************/

#include "rfeApi_error.h"
#include "rfeApi_params.h"
#include "rfeApi_types.h"


/******************************************************************************
 *                              TYPES
 *****************************************************************************/



/******************************************************************************
 *                              FUNCTIONS
 *****************************************************************************/

 /**
 * \brief This function starts continuous wave transmission
 * 
 * \details This function starts continuous wave transmission as configured 
 * in the given chirp profile with the frequency kept constant at the 
 * center frequency. This function cannot be used during an active radar cycle. 
 * This function returns whether rfe has accepted or rejected the API call.
 * 
 * \pre 
 * -#rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * -#rfeApi_state_t.isConfigured must be true
 * -#rfeApi_state_t.isRadarCycleActive is false
 * 
 * \param [in]      profileIndex - Index of the chirp profile to be used for
 *                  the continous wave transmission
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post Rfe is transmitting and receiving continous wave signal and
 * #rfeApi_state_t.functionalState becomes #rfeApi_functionalState_continuousWaveTransmission_e
 * 
 * \ingroup NIL
 */
void rfeApi_continuousWaveTransmissionStart(
    rfeApi_chirpProfileIndex_t profileIndex,
    RFE_API_ERROR_FUNCTION_PARAMETER
);


 /**
 * \brief This function stops continuous wave transmission.
 * 
 * \details This function stops continuous wave transmission.
 * This function cannot be used during an active radar cycle. This function 
 * returns whether rfe has accepted or rejected the API call.
 * 
 * \pre #rfeApi_state_t.functionalState must be #rfeApi_functionalState_continuousWaveTransmission_e
 * 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post Continous wave transmission not active and
 * #rfeApi_state_t.functionalState becomes #rfeApi_functionalState_idle_e
 * 
 * \ingroup NIL
 */
void rfeApi_continuousWaveTransmissionStop( RFE_API_ERROR_FUNCTION_PARAMETER );


 /**
 * \brief This function resets the receiver saturation counter
 * 
 * \details This function resets the receiver saturation counter for selected 
 * receivers. This function returns whether rfe has accepted or rejected 
 * the API call.
 * 
 * \pre #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * 
 * \param [in]      rxs - Selection of the receivers for which to reset the
 *                  saturation count. 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post Selected receiver saturation counters are reset to 0.
 * 
 * \ingroup NIL
 */
void rfeApi_resetRxSaturationCount(
    rfeApi_rxSelect_t rxs,
    RFE_API_ERROR_FUNCTION_PARAMETER
);


 /**
 * \brief This function resets the programmable decimation chain clipping counter
 * 
 * \details This function resets the programmable decimation chain clipping 
 * counter for selected receivers. This function returns whether rfe has 
 * accepted or rejected the API call.
 * 
 * \pre #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * 
 * \param [in]      pdcs - Selection of the programmable decimation chain for 
 *                  which to reset the saturation count. 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post Selected programmable decimation chain clipping counters are reset to 0.
 * 
 * \ingroup NIL
 */
void rfeApi_resetPdcClippingCount(
    rfeApi_rxSelect_t pdcs,
    RFE_API_ERROR_FUNCTION_PARAMETER
);


 /**
 * \brief TBD
 * 
 * \details TBD
 * This function returns whether rfe has accepted or rejected the API call.
 * 
 * \pre #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e
 * 
 * \param [in]      enable - True=enable, false=disable 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return NIL
 * 
 * \post TBD
 * 
 * \ingroup NIL
 */
void rfeApi_enableCsi2DataCorruption(
    bool enable,
    RFE_API_ERROR_FUNCTION_PARAMETER
);

#endif // !RFE_API_CMDS_H

