/*
    Copyright 2021 NXP  
    NXP Confidential. This software is owned or controlled by NXP and may only be 
    used strictly in accordance with the applicable license terms. By expressly 
    accepting such terms or by downloading, installing, activating and/or otherwise
    using the software, you are agreeing that you have read, and that you agree to
    comply with and are bound by, such license terms.  If you do not agree to be 
    bound by the applicable license terms, then you may not retain, install, 
    activate or otherwise use the software.
 */


/******************************************************************************
 *   Project              : SAF85xx_RFE_FW
 *   Platform             : SAF85xx
 *****************************************************************************/

#ifndef RFE_API_MONITORS_H
#define RFE_API_MONITORS_H


/******************************************************************************
 *                              INCLUDES
 *****************************************************************************/

#include "rfeApi_error.h"
#include "rfeApi_types.h"
#include "rfeApi_params.h"


/******************************************************************************
 *                              TYPES
 *****************************************************************************/

/**
 * This structure contains the saturation counts of each receiver
 */
typedef struct
{
    /** The saturation count of the in-phase path of the first receiver stage, for each receiver */
    uint32_t stage1I[RFE_API_RX_COUNT];
    /** The saturation count of the quadrature path of the first receiver stage, for each receiver */
    uint32_t stage1Q[RFE_API_RX_COUNT];
    /** The saturation count of the in-phase path of the second receiver stage, for each receiver */
    uint32_t stage2I[RFE_API_RX_COUNT];
    /** The saturation count of the quadrature path of the second receiver stage, for each receiver */
    uint32_t stage2Q[RFE_API_RX_COUNT];
} rfeApi_rxSaturationCount_t;

/**
 * This structure contains the clipping count of each PDC
 */
typedef struct
{
    /** The clipping count of each programmable decimation chain */
    uint32_t count[RFE_API_RX_COUNT];
} rfeApi_rxPdcClippingCount_t;

/**
 * This structure contains the temperature of each temperature sensor
 */
typedef struct
{
    /** The temperature of each temperature sensor */
    rfeApi_temperature_t temp[RFE_API_TEMPERATURE_SENSOR_COUNT];
} rfeApi_sensorTemperatures_t;


/******************************************************************************
 *                              FUNCTIONS
 *****************************************************************************/

 /**
 * \brief This function returns the saturation counts of each receiver
 * 
 * \details This function returns the saturation counts of each receiver. 
 * This function returns whether rfe has accepted or rejected the API call.
 * 
 * \pre  #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e.
 * 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return rfeApi_rxSaturationCount_t - Structure with the pdc saturation counts
 * 
 * \post NIL
 * 
 * \ingroup NIL
 */
rfeApi_rxSaturationCount_t rfeApi_getRxSaturationCount( RFE_API_ERROR_FUNCTION_PARAMETER );


 /**
 * \brief This function returns the clipping counts of each programmable decimation chain
 * 
 * \details This function returns the clipping counts of each programmable decimation chain. 
 * This function returns whether rfe has accepted or rejected the API call.
 * 
 * \pre  #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e.
 * 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return rfeApi_rxPdcClippingCount_t - Structure with the receiver clipping counts
 * 
 * \post NIL
 * 
 * \ingroup NIL
 */
rfeApi_rxPdcClippingCount_t rfeApi_getPdcClippingCount( RFE_API_ERROR_FUNCTION_PARAMETER );


 /**
 * \brief This function returns the temperature of each rfe temperature sensor
 * 
 * \details This function returns the temperature of each rfetemperature sensor. 
 * This function returns whether rfe has accepted or rejected the API call.
 * 
 * \pre  #rfeApi_state_t.functionalState must be #rfeApi_functionalState_idle_e.
 * 
 * \param [in,out]  RFE_API_ERROR_FUNCTION_PARAMETER - Error handling parameter:
 *                  On success #RFE_API_ERROR_IS_NO_ERROR is true
 *                  On failure #RFE_API_ERROR_IS_ERROR is true
 * 
 * \return rfeApi_sensorTemperatures_t - Structure with the rfe sensor temperatures
 * 
 * \post NIL
 * 
 * \ingroup NIL
 */
rfeApi_sensorTemperatures_t rfeApi_getRfeSensorTemperatures( RFE_API_ERROR_FUNCTION_PARAMETER );


#endif // !RFE_API_MONITORS_H

